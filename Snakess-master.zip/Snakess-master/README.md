# Snakess
A Python Snake Game created using pygame library.

Make sure you already have installed python version 3.x or later.

Just simply open your command prompt and type the command:
### pip install pygame
And then run the game by commanding :
### python Snakess.py
